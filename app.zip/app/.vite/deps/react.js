import {
  require_react
} from "./chunk-AK4TLUUY.js";
export default require_react();
