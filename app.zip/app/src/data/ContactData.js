export const contactInfo = [
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/60551ce3d7605982b090481f0b1b2c8d1ef1fae9d4de013f9213537d67951e86?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
      text: "Kijiji Beach, Dar es salaam",
      alt: "Location icon"
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/84e77131be9658a501ddd989286ffd9e3451f512420ca76590a63c399e56f2cf?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
      text: "+255 070000000",
      alt: "Phone icon"
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/TEMP/28b3dc7fa1f346b1c0232cb16196b216e84dfcd2f269febb8432e9b551c7eeef?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
      text: "info@kijijibeach.co.tz",
      alt: "Email icon"
    }
  ];