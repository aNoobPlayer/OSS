export const facilitiesPic = [{
    "images": [
      {
        "id": "facility-1",
        "src": "https://cdn.builder.io/api/v1/image/assets/TEMP/5e09e98f1bc4ccce37fc314170dae5a70f6104bf940a0f30bb0e65c5ecee2454?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
        "alt": "Luxury hotel facility showcasing amenities and services",
        "aspectRatio": "1.36"
      },
      {
        "id": "facility-2",
        "src": "https://cdn.builder.io/api/v1/image/assets/TEMP/9edc695c82108e38e8af06ac8cc44629ba27af05cef48d39ccdc9ba23dd7077c?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
        "alt": "Premium hotel accommodations and facilities view",
        "aspectRatio": "1.35"
      },
      {
        "id": "facility-3",
        "src": "https://cdn.builder.io/api/v1/image/assets/TEMP/2b05672c3cbd0fb24ef7aa1da02779ad40017ba4d18da82aa7c27b93b30714c2?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
        "alt": "Exclusive hotel facilities and recreational areas",
        "aspectRatio": "1.38"
      }
    ]
  }];