export const roomData = [
  {
    id: 1,
    title: "Kijiji Beach Single",
    rating: 4.9,
    price: 300,
    image: "https://cdn.builder.io/api/v1/image/assets/TEMP/411da16b9ba777cdca12abad1e3cbc1005101ae4ed448144b148ab6bf1493d6a?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
    ratingImage: "https://cdn.builder.io/api/v1/image/assets/TEMP/94db0b80dca5f7779cef04f8119695b252c523254265989819dba096f0101720?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6"
  },
  {
    id: 2,
    title: "Kijiji Beach Family",
    rating: 4.9,
    price: 300,
    image: "https://cdn.builder.io/api/v1/image/assets/TEMP/411da16b9ba777cdca12abad1e3cbc1005101ae4ed448144b148ab6bf1493d6a?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
    ratingImage: "https://cdn.builder.io/api/v1/image/assets/TEMP/e135228c659082a87d5ac821e124b45a124b44b7cd548a27241b487daa41f434?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6"
  },
  {
    id: 3,
    title: "Kijiji Beach Couple",
    rating: 4.9,
    price: 300,
    image: "https://cdn.builder.io/api/v1/image/assets/TEMP/411da16b9ba777cdca12abad1e3cbc1005101ae4ed448144b148ab6bf1493d6a?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
    ratingImage: "https://cdn.builder.io/api/v1/image/assets/TEMP/36e1b6739fc7a8ef5ed3ca7a971e69c4e7fe86705648ff64f77e139ebff92df8?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6"
  },
  {
    id: 4,
    title: "Nice hotel",
    rating: 5,
    price: 150,
    image: "https://cdn.builder.io/api/v1/image/assets/TEMP/411da16b9ba777cdca12abad1e3cbc1005101ae4ed448144b148ab6bf1493d6a?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6",
    ratingImage: "https://cdn.builder.io/api/v1/image/assets/TEMP/92e48d3ae6d48211aa38dae7cf60a95ef2c1375cdaacca8efa020765fd23956b?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6"
  }
];