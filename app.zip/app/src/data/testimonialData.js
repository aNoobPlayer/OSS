export const testimonialData = [
  {
    id: 1,
    name: "Titus Wealth",
    location: "Dar es salaam , Tanzania",
    rating: 4.8,
    review: "it was so good and wonderfull ilike this place so much",
    starIcon: "https://cdn.builder.io/api/v1/image/assets/TEMP/353261a59e2c5d47076e5d90027eba30d0502c8727cadc6c8ec83ee467e1c019?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6"
  },
  {
    id: 2,
    name: "Dastani Ferdinandi",
    location: "Nairobi, Kenya",
    rating: 4.3,
    review: "very exclusive service. really a very comfortable hotel the mattress is very soft like the rendang meat that I met yesterday",
    starIcon: "https://cdn.builder.io/api/v1/image/assets/TEMP/353261a59e2c5d47076e5d90027eba30d0502c8727cadc6c8ec83ee467e1c019?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6"
  },
  {
    id: 3,
    name: "Gilbert Robert",
    location: "Dar es Salaam , Tanzania",
    rating: 4.5,
    review: "Good rooms and services ill visit every weekend to enjoy with my family",
    starIcon: "https://cdn.builder.io/api/v1/image/assets/TEMP/4ff9ab0139336c4bd4e86ea9c883af84d6f5d415af534473473c6928efdac3c0?placeholderIfAbsent=true&apiKey=69b090b19e3a45eaa7b94492d5c1e0b6"
  }
];